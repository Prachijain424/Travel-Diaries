import React from 'react'

export const About = () => {
  return (
    <div className='container ' style={{margin: "82px auto 487px auto"}}>
        <h2>About the Travel Diary</h2>
        <p>Travel Diary is created by the team of devlopers of MNNIT Allhabad. The motive to devlope the platform is to help the people manage their works and list their targets. It gives the user the power to Add, Read, Execute and Delete their tasks. </p>
    </div>
  )
}

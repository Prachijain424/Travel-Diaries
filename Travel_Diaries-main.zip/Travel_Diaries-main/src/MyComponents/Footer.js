import React from 'react'

export const Footer = () => {
  return (
    <footer className='bg-dark text-light py-3' style={{margin: "449px auto 0px auto" ,position:'fixed', bottom: '0px', width:'100%'}} >
        <p className="text-center">Copyright &copy; TravelDiaries.com</p>
    </footer>
  )
}
